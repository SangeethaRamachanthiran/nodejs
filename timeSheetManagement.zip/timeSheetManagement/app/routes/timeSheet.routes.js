module.exports = app => {
  const timesheets = require("../controller/timeSheet.controller.js");

  var router = require("express").Router();


  // router.post("/", timesheets.addTimesheet);
  router.get("/", timesheets.findAllDetails);

  app.use('/api/timesheets', router);
};

// const express = require("express");
// const controllers = require("../controller/timeSheet.controller.js");
// const router = express.Router();

// router.route("/").get(controllers.getAllTodos);
// module.exports = router;