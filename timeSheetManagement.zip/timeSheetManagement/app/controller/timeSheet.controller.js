const dbModel = require("../models");
const db = require("../models/timeSheet.model.js");
const Timesheet = db.timesheets;
require("mysql");
// const sequelize = require("sequelize");


exports.findAllDetails = (req, res) => {
  // const username = req.query.username;

  db.timesheets.findAll()
    .then(data => {
      res.status(200).json({
              data: data
            });
    })
};







// const getAllDetails = async (req, res) => {

//   const timesheet = await Timesheet.findAll();

//   console.log(JSON.stringify(timesheet, null, 2));
//   res.status(200).send(timesheet)

// }

// module.exports = {
//   getAllDetails
// }





const conn = require("../config/db_config.js");

exports.getAllTodos = (req, res, next) => {
  conn.query("SELECT * FROM timesheets", function (err, data, fields) {
    res.status(200).json({
      data: data
    });
  });
 };